package com.plants.nature.heaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NatureHeavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(NatureHeavenApplication.class, args);
	}

}

package com.plants.nature.heaven.repository;

import com.plants.nature.heaven.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product , Integer> {

    Product findByName(String name);
}

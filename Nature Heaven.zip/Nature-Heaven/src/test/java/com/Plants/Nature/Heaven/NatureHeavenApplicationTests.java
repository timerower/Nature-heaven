package com.Plants.Nature.Heaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NatureHeavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
